typedef struct state{
	u16 xspeed;
	u16 yspeed;
	u16 xaccel;
	u16 yaccel;
	u8 xchange;
	u8 ychange;
	u8 framestart;
	u8 totalframes;
	//u16 pointer; //(function for state-durational conditionals.)
	


}state;
